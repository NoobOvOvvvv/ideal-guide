# Amazon Product Visual Studio V5

A category-adaptive Codex Skill for end-to-end ecommerce visual production.

## Three core capabilities
1. Search the web for product-use scene references and, separately when relevant, print/surface-design inspiration.
2. Develop original print or surface artwork from visual research when the product benefits from it; approve and lock the artwork before application.
3. Plan and produce a buyer-led Amazon image suite: main image, secondary images, lifestyle scenes, dimensions, features/details and A+ modules.

## V5 improvements
- Category routing: textiles, apparel, home, electronics, kitchen/tools, beauty/consumables, toys/pets/outdoor and more.
- Separate scene-reference research from print-inspiration research.
- Conditional print-design stage: no forced artwork for products that do not need it.
- Three independent locks: product, artwork and visual style.
- Buyer-question-led storyboard and independently planned A+ modules.
- Controlled batch generation, product-fidelity validation and asset-level QA.
- Clear LinkFox integration boundaries: use only verified installed/authenticated capabilities.

## Install
Copy the `amazon-product-visual-studio` folder into either:
- Global: `%USERPROFILE%\.agents\skills\amazon-product-visual-studio\`
- Project: `<your-project>\.agents\skills\amazon-product-visual-studio\`

Then invoke in Codex with `$amazon-product-visual-studio`.

## Recommended first use
Provide product photos, target marketplace, confirmed specifications, variants and any existing brand assets. The Skill will inspect available materials, establish a product identity lock, research scene references, and determine whether a print-design stage is relevant.

## Important
This Skill defines a workflow; it does not itself provide browser access, image-generation capability, LinkFox account authorization, API access or generation credits. Codex must have the relevant tools/skills configured. Product claims, measurements, licenses and marketplace requirements must be verified before publishing.
