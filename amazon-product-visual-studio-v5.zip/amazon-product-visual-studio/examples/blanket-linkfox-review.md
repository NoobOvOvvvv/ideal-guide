# Example: Review of the supplied LinkFox blanket image set

## Visual strengths observed
- The 11-image set behaves like one visual family: warm cream, beige and taupe palette; soft daylight; calm bedroom/living-room interiors; restrained serif-style English headlines; repeated close-up circles and simple icons.
- The square images cover a clean product presentation, bed/sofa lifestyle, blanket texture/detail and benefit-led compositions.
- The wide images work as A+ style modules and maintain the same palette and typography.
- This consistency is a useful reference for a V3 Style Bible and staged image-family generation.

## Claims that require confirmation before reuse
The generated images contain or imply: reversible/two-sided construction, silky-smooth side, fluffy/sherpa-like side, sofa throw, air-conditioning blanket, nap blanket, reinforced edging, and specific stitching/edge construction. These are not automatically true because they appear in a generated image. Confirm each against the actual product and supplier specification before placing it in listing copy or images.

## Product-fidelity checks for blankets
- Keep the real blanket dimensions and proportions consistent across bed, sofa and close-up scenes.
- Preserve actual pile length, fabric surface, edge binding, stitching and drape.
- Do not invent a contrasting reverse side, sherpa lining, quilting or reinforced hem.
- Keep color variants faithful: cream, gray and brown should not drift into near-identical shades.
- Lifestyle folds may obscure parts of the blanket, but should not create new seams, borders or fabric layers.
- Avoid implying the blanket covers a whole bed/sofa if the selected size does not support that scale.

## Recommended family direction
A calm, warm, natural-home editorial direction: soft window daylight, ivory/taupe/wood environment, uncluttered furniture, close material details, restrained English typography and consistent negative space. Use the real product reference as the identity anchor for every generation batch.
