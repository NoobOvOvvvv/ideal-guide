# Example: Flannel Blanket Workflow

## Product facts supplied by user
- Product: flannel blanket
- Material: polyester fiber
- Market: Amazon US
- Sizes: multiple sizes (exact options and measurements must be supplied before dimension graphics)
- Colors: ivory, gray, coffee
- Confirmed benefits: soft to the touch; warm

## Stage 1 — Scene research
Search for current US bedroom, sofa, reading nook and cozy seasonal blanket scenes. Build a board with multiple sources and group them into coherent directions such as warm neutral bedroom, modern minimalist living room and cozy reading corner. Record URLs and mark image rights as unverified unless checked.

## Stage 2 — Print design
If the user wants a new blanket print, choose one approved scene direction and translate its high-level visual language into original blanket artwork. For example, derive a warm-neutral palette and calm botanical motif family from several references, but do not reproduce a specific fabric pattern or illustration. Generate a flat repeat tile separately, inspect edges and approve the artwork lock.

If the user has not requested a new print, do not invent one: use the existing blanket pattern/color as locked product truth.

## Stage 3 — Listing image suite
- Main: accurate blanket product view on white background, compliant with current Amazon rules.
- Secondary: overview showing texture and available color variants only if all variants are confirmed.
- Lifestyle: bedroom, sofa and reading-corner scenes based on the reference board.
- Dimension: create only after exact size measurements are supplied.
- Feature: softness and warmth, without unsupported technical claims.
- Detail: close-up of the real flannel surface and stitching as supported by source photos.
- A+: consistent brand/lifestyle sequence with the same product and approved print/color.
