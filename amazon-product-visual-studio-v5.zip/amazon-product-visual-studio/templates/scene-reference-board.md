# Scene Reference Board

## Product and audience
- Product/category:
- Marketplace/region:
- Target buyer:
- Intended use / season / theme:

## Search strategy
- Search queries:
- Search date:
- Sites/sources checked:

## Reference entries
For each reference:
- Reference ID:
- Page title / source:
- URL:
- Access date:
- Rights/usage status: verified / not verified / restricted / unknown
- Scene and subject:
- Palette:
- Motifs or shapes:
- Composition / camera:
- Lighting / texture:
- Useful design lesson:
- Do not copy:

## Candidate directions
### Direction A
- Concept:
- Buyer fit:
- Scene language:
- Print-design potential:
- Risks:

### Direction B
- Concept:
- Buyer fit:
- Scene language:
- Print-design potential:
- Risks:

## Selected direction and rationale
