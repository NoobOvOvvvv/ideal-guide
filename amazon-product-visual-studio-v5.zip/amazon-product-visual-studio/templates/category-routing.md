# Category Routing

- Product category: [ ]
- Target marketplace / language: [ ]
- Is print/surface artwork relevant? [yes / no / conditional]
- Reason: [ ]

## Relevant visual priorities
- Product truth attributes: [ ]
- Buyer questions: [ ]
- Scene types to research: [ ]
- Image roles required: [ ]
- A+ modules relevant: [ ]
- Category-specific policy/safety concerns: [ ]

## Skip / do not force
- Irrelevant image roles: [ ]
- Unsupported claims or visuals: [ ]
