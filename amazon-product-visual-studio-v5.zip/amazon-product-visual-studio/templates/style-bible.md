# Style Bible

- Concept name:
- Buyer impression:
- Marketplace / audience:
- Palette:
- Background / environment family:
- Lighting direction and softness:
- Shadow / contrast:
- Camera / lens feel:
- Composition / negative space:
- Typography:
- Icon / annotation style:
- Copy tone:
- Product rendering rules:
- Props allowed:
- Props prohibited:
- Consistency rules across images:
- Risks and mitigation:
