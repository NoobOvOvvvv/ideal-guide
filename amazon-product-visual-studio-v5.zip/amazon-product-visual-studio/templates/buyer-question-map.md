# Buyer Question Map

| Buyer question / objection | Evidence available | Image role | Key visual | Copy / claim boundary |
|---|---|---|---|---|
| What is it? | | Main image / overview | | |
| What makes it useful? | | Feature image | | |
| What does it look/feel like? | | Lifestyle / detail | | |
| Will it fit my needs? | | Dimension / compatibility | | |
| What is included? | | Contents image | | |
| How do I use it? | | Use/how-to (if relevant) | | |
