# Approved Artwork Lock

- Artwork name/version:
- Source file:
- Approval status/date:
- Reference-board direction:
- Motifs and relative proportions:
- Palette:
- Repeat type / tile dimensions:
- Scale / density / spacing:
- Orientation:
- Product application notes:
- Do not alter:
- Known limitations:
