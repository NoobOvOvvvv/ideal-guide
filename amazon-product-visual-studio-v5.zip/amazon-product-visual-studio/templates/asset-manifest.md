# Final Asset Manifest

| Filename | Image role | Pixel size | Ratio | Language | QA status | Notes |
|---|---|---|---|---|---|---|

## Source files preserved at

## Unresolved issues

## Export details
- File format:
- Color profile (if known):
- Destination:
