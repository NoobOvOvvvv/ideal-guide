# Image Storyboard

| ID | Image role | Buyer question | Key message | Verified fact(s) | Scene/composition | Copy | Ratio | Prompt / edit brief | QA gate |
|---|---|---|---|---|---|---|---|---|---|
| 01 | Main | What exactly is the product? | | | | | | | |
| 02 | Overview | What is the main value? | | | | | | | |
| 03 | Lifestyle | How is it used? | | | | | | | |
| 04 | Detail | What is the material/build like? | | | | | | | |
| 05 | Feature | What verified benefit matters? | | | | | | | |
| 06 | Dimensions | What size is it? | | | | | | | |
| 07 | A+ | Why choose this product? | | | | | | | |

Remove irrelevant rows and add only image roles that answer a distinct buyer question.
