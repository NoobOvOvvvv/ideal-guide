# Product Identity Sheet

## Basic information
- Product name/category:
- Marketplace / region / language:
- Target buyer:
- Brand / model:
- Variants / colors / sizes:

## Confirmed facts
| Attribute | Confirmed value | Evidence/source |
|---|---|---|
| Material | | |
| Construction | | |
| Dimensions | | |
| Weight | | |
| Features | | |
| Benefits | | |
| Package contents | | |
| Care / use | | |

## Visual observations (not claims)
- Silhouette:
- Surface / texture:
- Color appearance:
- Seams / edges / details:

## Unknown / needs confirmation
- 

## Visual lock list
- Must preserve:
- Must not invent/change:

## Claim lock list
- Approved claims:
- Prohibited / unsupported claims:
- Needs evidence:

## Source asset inventory
| Filename | View/angle | Useful details | Limitations |
|---|---|---|---|
