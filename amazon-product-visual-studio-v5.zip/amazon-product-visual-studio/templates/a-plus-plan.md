# A+ Content Plan

- Marketplace: [ ]
- Brand facts supplied: [ ]
- Module specification source/date: [ ]

| Module | Buyer question | Visual composition | Copy | Supporting facts | Dimensions/status |
|---|---|---|---|---|---|
| Hero | | | | | |
| Product overview | | | | | |
| Feature | | | | | |
| Material/detail | | | | | |
| Lifestyle | | | | | |
| Comparison (if relevant/permitted) | | | | | |
| Brand story (if substantiated) | | | | | |

## QA / unresolved items
- [ ]
